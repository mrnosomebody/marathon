create function add_fine() returns trigger
    language plpgsql
as
$$
BEGIN
    IF  (select distinct sum(fine_amount) over(PARTITION BY f.id_car) from fines f  where id_car = new.id_car) > 10000 THEN
        update car set blocked=true where car.id = new.id_car;
        RETURN NEW;
    ELSE
        update car set blocked=true where car.id = new.id_car;
        return new;
    END IF;
END;
$$;

alter function add_fine() owner to postgres;

